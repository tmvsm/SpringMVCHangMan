package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller("telusko")
public class chooseController {

	static String palavraAdivinhar;
	static char [] palavraAdivinharChar;
	static char [] palavraAsteriscos;
	static int falhas = 0;
	static boolean fim = false;

	@RequestMapping("/choose")
	public ModelAndView choose(HttpServletRequest request, HttpServletResponse response) {

		String categoria = (String) request.getParameter("cat1");
		String dificuldade = request.getParameter("dif1");

		System.out.println(categoria);
		System.out.println(dificuldade);

		ModelAndView mv = new ModelAndView();
		mv.setViewName("display.jsp");

		String palavraEscolhida = getRandomWord(dificuldade, categoria);
		System.out.println("Palavra a adivinhar: " + palavraEscolhida);


		mv.addObject("palavra", palavraEscolhida);

		return mv;
	}

	@RequestMapping("/guess")
	public ModelAndView guess(HttpServletRequest request, HttpServletResponse response) {

		String letra = request.getParameter("letra1");
		char letraChar = (char) letra.charAt(0);

		System.out.println("Letra submetida pelo utilizador: " + letra);

		ModelAndView mvGuess = new ModelAndView();
		ModelAndView mvEnd = new ModelAndView();

		mvGuess.setViewName("guess.jsp");
		mvEnd.setViewName("gameOver.jsp");

		mvGuess.addObject("letra", letra);
		mvEnd.addObject("palavra", palavraAdivinhar);

		jogoForca(palavraAdivinharChar, letraChar);
		if(fim==false ) {
			String asteriscos2 = String.valueOf(palavraAsteriscos);
			mvGuess.addObject("asteriscos", asteriscos2);

			return mvGuess;
		} else {
			return mvEnd;
		}
	}

	public static void jogoForca(char[] palavraAdivinharChar, char letra) {


		if(!adivinharCaracter(letra, palavraAsteriscos, palavraAdivinharChar)) {
			falhas++;
		}
		if(verificaEstado(palavraAsteriscos)) {
			fim = true;
			System.out.println("A palavra �: " + String.valueOf(palavraAdivinharChar) + " e falhas-te: " + falhas + " vezes ");


		}


	}

	private static boolean verificaEstado(char[] palavraAsteriscos) {
		for(int i = 0; i<palavraAsteriscos.length; i++)
			if(palavraAsteriscos[i] == '*') 
				return false;
		return true;

	}

	private static boolean adivinharCaracter(char letra, char[] palavraAsteriscos, char[] palavraAdivinharChar) {

		boolean encontrouCaracter = false;
		int tentativas = 0;

		for(int i = 0; i<palavraAdivinharChar.length; i++) {
			if(palavraAdivinharChar[i] == letra) {
				if(palavraAsteriscos[i] == letra && tentativas == 0) {
					System.out.println("J� adivinhou esse caracter");
					tentativas++;
				} else {
					palavraAsteriscos[i] = letra;
					encontrouCaracter = true;
				}
			};
		}
		return encontrouCaracter;
	}


	/*
	 * Codigo para encontrar a palavra a utilizar
	 */

	public String getRandomWord(String dificuldade, String categoria) {
		String palavra = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			String url1 = "jdbc:mysql://localhost:3306/db_hibernate";
			String user = "root";
			String password = "root";

			Connection conn = DriverManager.getConnection(url1, user, password);



			Statement stmt = conn.createStatement();
			ResultSet resultQuery = stmt.executeQuery("select * from palavra p, dificuldade d, categoria c, palavra_categoria pc where d.DIFICULDADE_DESCRICAO ="
					+ " '" + dificuldade + "' and p.dificuldade_DIFICULDADE_ID = d.DIFICULDADE_ID and c.CATEGORIA_DESCRICAO='" + categoria + "' "
					+ "and pc.CATEGORIA_ID = c.CATEGORIA_ID and pc.PALAVRA_ID = p.PALAVRA_ID;");
			ArrayList<String> resultados = new ArrayList<String>();

			while(resultQuery.next()) {
				String nome = resultQuery.getString("palavra_descricao");
				resultados.add(nome);
			}


			Random r = new Random();
			String palavraFinal = resultados.get(r.nextInt(resultados.size()));




			palavra = palavraFinal;

			palavraAdivinhar = palavraFinal;
			palavraAdivinharChar = palavraAdivinhar.toCharArray();
			palavraAsteriscos = new char[palavraAdivinharChar.length];
			Arrays.fill(palavraAsteriscos, '*');			

		} catch (Exception e) {
			System.out.println(e);
		}

		return palavra;
	}

}
